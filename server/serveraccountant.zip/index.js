import express from "express";
import cors from 'cors';
import { userRouter } from "./routes/userroute.js";
import { returnRouter } from "./routes/returnsroute.js";
import { advancedetailsRouter } from "./routes/advancedetailsroute.js";
import { returnsdetailsRouter } from "./routes/returnsdetailsroute.js";
import { advanceRouter } from "./routes/advanceroute.js";



const app = express();

app.use(cors({
    origin: ["http://localhost:3000"],
    methods: ['GET', 'POST', 'PUT'],
    credentials: true
  }));

app.use(express.json());

app.use('/auth', userRouter);
app.use('/auth', advanceRouter);
app.use('/auth', returnRouter);
app.use('/auth', advancedetailsRouter);
app.use('/auth', returnsdetailsRouter);


app.listen(3001, () => {
    console.log("Server is running");
});