import express from 'express';
import { con as connection } from '../utils/db.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
const router = express.Router();

router.get('/returnsinfo/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;

    const sql = `
        SELECT 
            r.returns_code,
            r.advance_code,
            r.report_name, 
            r.total_amount, 
            r.to_be_reimbursed, 
            r.purpose, 
            r.rejection_reason,
            r.project_code, -- Include project_code in the SELECT statement
            IFNULL(SUM(ra.amount_advanced), 0) AS advance_amount
        FROM returns r
        LEFT JOIN returnsamounttable ra ON r.returns_code = ra.returns_code
        WHERE r.returns_code = ?
        GROUP BY 
            r.returns_code,
            r.advance_code,
            r.report_name, 
            r.total_amount, 
            r.to_be_reimbursed, 
            r.purpose,
            r.rejection_reason,
            r.project_code; -- Group by project_code as well
    `;

    connection.query(sql, [referenceNumber], (err, results) => {
        if (err) {
            console.error('Error fetching returns info:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Return not found' });
        }

        res.json({ returnsInfo: results[0] });
    });
});

router.get('/returnsdetails/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;
    const sql = 'SELECT dateofexpense, category, description, amount_advanced, amount_expended, amount_left, receipt_link FROM returnsamounttable WHERE returns_code = ?';

    connection.query(sql, [referenceNumber], (err, results) => {
        if (err) {
            console.error('Error fetching returns details:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        res.json({ returnsDetails: results });
    });
});

router.post('/retapprove/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;

    // Begin a transaction
    connection.beginTransaction((err) => {
        if (err) {
            console.error('Error beginning transaction:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        // Step 1: Update request status to 'approved' (only if status is currently 'pending')
        const updateRequestSQL = `
            UPDATE returns 
            SET status = 'ApprovedA' 
            WHERE returns_code = ?
        `;
        connection.query(updateRequestSQL, [referenceNumber], (err, results) => {
            if (err) {
                console.error('Error updating request status:', err);
                return connection.rollback(() => {
                    res.status(500).json({ error: 'Internal server error' });
                });
            }

            if (results.affectedRows === 0) {
                return connection.rollback(() => {
                    res.status(404).json({ error: 'Request not found or already approved' });
                });
            }

            // Commit the transaction if update was successful
            connection.commit((err) => {
                if (err) {
                    console.error('Error committing transaction:', err);
                    return connection.rollback(() => {
                        res.status(500).json({ error: 'Internal server error' });
                    });
                }
                res.json({ message: 'Returns approved successfully' });
            });
        });
    });
});

router.post('/retreject/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;
    const { reason } = req.body;
    const sql = 'UPDATE returns SET status = ?, rejection_reason = ? WHERE returns_code = ?';

    connection.query(sql, ['RejectedA', reason, referenceNumber], (err, results) => {
        if (err) {
            console.error('Error rejecting returns:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'Returns not found' });
        }

        res.json({ message: 'Returns rejected successfully' });
    });
});

export { router as returnsdetailsRouter };
