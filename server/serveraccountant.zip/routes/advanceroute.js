import express from 'express';
import { con } from '../utils/db.js';
const router = express.Router();
import { authenticateToken } from '../middleware/authenticateToken.js';



router.get('/project_codes', async (req, res) => {
    try {
        const sql = "SELECT project_code FROM project ";
        con.query(sql, (err, results) => {
            if (err) {
                console.error("Error fetching project codes: ", err);
                return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch project codes" });
            }
            const projectCodes = results.map(row => row.project_code);
            res.status(200).json({ success: true, projectCodes });
        });
    } catch (error) {
        console.error("Error fetching project codes: ", error);
        res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch project codes" });
    }
});

// Endpoint to get categories by project code
router.get('/categories/:projectCode', async (req, res) => {
    const { projectCode } = req.params;
    try {
        const sql = "SELECT DISTINCT category FROM funds_allocation WHERE project_code = ?";
        con.query(sql, [projectCode], (err, results) => {
            if (err) {
                console.error("Error fetching categories: ", err);
                return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch categories" });
            }
            const categories = results.map(row => row.category);
            res.status(200).json({ success: true, categories });
        });
    } catch (error) {
        console.error("Error fetching categories: ", error);
        res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch categories" });
    }
});

router.get('/pending_advances', authenticateToken, (req, res) => {
    const sql = `
        SELECT 
            datetime AS date,
            advance_code AS referenceNumber,
            advance_name AS name,
            email AS submitter,
            total_amount AS total,
            project_code AS projectCode
        FROM 
            advance
        WHERE 
            status = "ApprovedC"
            ORDER BY 
            datetime DESC`;

    con.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching pending advances: ", err);
            return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch pending advances" });
        }
        res.status(200).json(results);
    });
});

router.get('/approved_advances', authenticateToken, (req, res) => {
    const sql = `
        SELECT 
            datetime AS date,
            advance_code AS referenceNumber,
            advance_name AS name,
            email AS submitter,
            total_amount AS total,
            project_code AS projectCode
        FROM 
            advance
        WHERE 
            status = "ApprovedA"
            ORDER BY 
            datetime DESC`;

    con.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching approved advances: ", err);
            return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch pending advances" });
        }
        res.status(200).json(results);
    });
});

router.get('/projectinfo/:projectCode', authenticateToken, (req, res) => {
    const { projectCode} = req.params;

    const projectSql = `
SELECT 
    project_code AS projectCode
FROM 
    project
WHERE 
    project_code = ?`;

    con.query(projectSql, [projectCode], (err, projectResults) => {
        if (err) {
            console.error("Error fetching project details: ", err);
            return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch project details" });
        }
            res.status(200).json({
                project: projectResults[0], // Assuming project_code is unique, so we take the first result
            });
    });
});

router.get('/rejected_advances', authenticateToken, (req, res) => {
    const sql = `
        SELECT 
            datetime AS date,
            advance_code AS referenceNumber,
            advance_name AS name,
            email AS submitter,
            total_amount AS total,
            project_code AS projectCode
        FROM 
            advance
        WHERE 
            status = "RejectedA"
            ORDER BY 
            datetime DESC`;

    con.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching rejected advances: ", err);
            return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch pending advances" });
        }
        res.status(200).json(results);
    });
});

export { router as advanceRouter };
