import express from 'express';
import { con } from '../utils/db.js';
import { authenticateToken } from '../middleware/authenticateToken.js';

const router = express.Router();

// Endpoint to get project codes for the returns form
router.get('/project_codes',authenticateToken, (req, res) => {
    const sql = "SELECT project_code FROM project";
    con.query(sql,(err, results) => {
        if (err) {
            console.error("Error fetching project codes: ", err);
            return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch project codes" });
        }
        const projectCodes = results.map(row => row.project_code);
        res.status(200).json({ success: true, projectCodes });
    });
});

// Endpoint to get advance codes for the returns form
router.get('/advance_codes/:email',authenticateToken, (req, res) => {
    const email = req.params.email
    const sql = "SELECT advance_code FROM advance WHERE status ='ApprovedC' AND email = ?";
    con.query(sql, [email],(err, results) => {
        if (err) {
            console.error("Error fetching advance codes: ", err);
            return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch advance codes" });
        }
        const advanceCodes = results.map(row => row.advance_code);
        res.status(200).json({ success: true, advanceCodes });
    });
});

// Endpoint to get categories by project code for the returns form
router.get('/categories/:projectCode',authenticateToken, async (req, res) => {
    const { projectCode } = req.params;
    try {
        const sql = "SELECT DISTINCT category FROM funds_allocation WHERE project_code = ?";
        con.query(sql, [projectCode], (err, results) => {
            if (err) {
                console.error("Error fetching categories: ", err);
                return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch categories" });
            }
            const categories = results.map(row => row.category);
            res.status(200).json({ success: true, categories });
        });
    } catch (error) {
        console.error("Error fetching categories: ", error);
        res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch categories" });
    }
});

// Endpoint to get advance details by advance code
// Route to fetch advance details for a specific advance code
router.get('/advance_details/:advanceCode',authenticateToken, async (req, res) => {
    const advanceCode = req.params.advanceCode;
    try {
        // Query to fetch advance details for the given advance code
        const sql = "SELECT category, description, amount FROM advanceamounttable WHERE advance_code = ?";
        con.query(sql, [advanceCode], (err, results) => {
            if (err) {
                console.error("Error fetching advance details:", err);
                return res.status(500).json({ success: false, message: "Internal server error" });
            }
            if (results.length > 0) {
                res.json({ success: true, advanceDetails: results });
            } else {
                res.status(404).json({ success: false, message: 'Advance details not found' });
            }
        });
    } catch (error) {
        console.error('Error fetching advance details:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

router.get('/report_summaries/:email',authenticateToken, (req, res) => {
    const sql = `
        SELECT 
            report_name AS reportdetails,
            total_amount AS total,
            to_be_reimbursed AS tobereimbursed,
            status AS status
        FROM 
            returns
        WHERE 
        status IN ("ApprovedA", 'RejectedA')
        ORDER BY 
            date_time DESC
     `;

con.query(sql,(err, results) => {
    if (err) {
        console.error("Error fetching report summary: ", err);
        return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch report summary" });
    }
    res.status(200).json(results);
});
});


router.get('/pending_returns',authenticateToken, async (req, res) => {
    const sql = `
    SELECT 
        date_time AS date,
        returns_code AS referenceNumber,
        report_name AS name,
        email AS submitter,  -- Assuming 'User' will be replaced with the actual user field when available
        total_amount AS total,
        to_be_reimbursed AS tobereimbursed
    FROM 
        returns
    WHERE 
        status = "ApprovedC"
        ORDER BY 
            date_time DESC`;

con.query(sql, (err, results) => {
    if (err) {
        console.error("Error fetching pending returns: ", err);
        return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch pending returns" });
    }
    res.status(200).json(results);
});
});

router.get('/approved_returns',authenticateToken, async (req, res) => {
    const sql = `
    SELECT 
        date_time AS date,
        returns_code AS referenceNumber,
        report_name AS name,
        email AS submitter,  -- Assuming 'User' will be replaced with the actual user field when available
        total_amount AS total,
        to_be_reimbursed AS tobereimbursed
    FROM 
        returns
    WHERE 
        status = "ApprovedA"
        ORDER BY 
            date_time DESC`;

con.query(sql, (err, results) => {
    if (err) {
        console.error("Error fetching approved returns: ", err);
        return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch pending returns" });
    }
    res.status(200).json(results);
});
});

router.get('/rejected_returns',authenticateToken, async (req, res) => {
    const sql = `
    SELECT 
        date_time AS date,
        returns_code AS referenceNumber,
        report_name AS name,
        email AS submitter,  -- Assuming 'User' will be replaced with the actual user field when available
        total_amount AS total,
        to_be_reimbursed AS tobereimbursed
    FROM 
        returns
    WHERE 
        status = "RejectedA"
        ORDER BY 
            date_time DESC`;

con.query(sql, (err, results) => {
    if (err) {
        console.error("Error fetching rejected returns: ", err);
        return res.status(500).json({ success: false, message: "Internal Server Error: Could not fetch pending returns" });
    }
    res.status(200).json(results);
});
});

export { router as returnRouter };
