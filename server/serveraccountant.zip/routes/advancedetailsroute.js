import express from 'express';
import { con as connection } from '../utils/db.js';
import { authenticateToken } from '../middleware/authenticateToken.js';
const router = express.Router();

router.get('/advanceinfo/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;
    const sql = `SELECT advance_name, project_code, total_amount, rejection_reason FROM advance WHERE advance_code = ?`;

    connection.query(sql, [referenceNumber], (err, results) => {
        if (err) {
            console.error('Error fetching advance info:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Advance not found' });
        }

        res.json({ advanceInfo: results[0] });
    });
});

router.get('/advancedetails/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;
    const sql = 'SELECT category, description, amount, amountAllocated, amountUsed FROM advanceamounttable WHERE advance_code = ?';

    connection.query(sql, [referenceNumber], (err, advanceDetails) => {
        if (err) {
            console.error('Error fetching advance details:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }
        if (advanceDetails.length === 0) {
            return res.status(404).json({ error: 'Advance details not found' });
        }

        const response = {
            advanceDetails: advanceDetails
        };

        res.json(response);
    });
});

router.post('/advapprove/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;

    // Begin a transaction
    connection.beginTransaction((err) => {
        if (err) {
            console.error('Error beginning transaction:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        // Step 1: Update request status to 'approved' (only if status is currently 'pending')
        const updateRequestSQL = `
            UPDATE advance 
            SET status = 'ApprovedA' 
            WHERE advance_code = ?
        `;
        connection.query(updateRequestSQL, [referenceNumber], (err, results) => {
            if (err) {
                console.error('Error updating request status:', err);
                return connection.rollback(() => {
                    res.status(500).json({ error: 'Internal server error' });
                });
            }

            if (results.affectedRows === 0) {
                return connection.rollback(() => {
                    res.status(404).json({ error: 'Request not found or already approved' });
                });
            }

            // Commit the transaction if update was successful
            connection.commit((err) => {
                if (err) {
                    console.error('Error committing transaction:', err);
                    return connection.rollback(() => {
                        res.status(500).json({ error: 'Internal server error' });
                    });
                }
                res.json({ message: 'Advance approved successfully' });
            });
        });
    });
});

router.post('/reject/:referenceNumber', authenticateToken, (req, res) => {
    const { referenceNumber } = req.params;
    const { reason } = req.body;
    const sql = 'UPDATE advance SET status = ?, rejection_reason = ? WHERE advance_code = ?';

    connection.query(sql, ['RejectedA', reason, referenceNumber], (err, results) => {
        if (err) {
            console.error('Error rejecting advance:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'Advance not found' });
        }

        res.json({ message: 'Advance rejected successfully' });
    });
});

export { router as advancedetailsRouter }
